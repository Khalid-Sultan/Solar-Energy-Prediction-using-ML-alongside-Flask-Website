# -*- coding: utf-8 -*-
"""
Created on Sun Oct  6 07:38:44 2019

@author: gemme
"""

import os
import numpy as np
from keras.models import Sequential
from keras import layers
from keras.optimizers import RMSprop
import pandas as pd
#Import and pre-process data for future applications

df = pd.read_csv('dataset/daily.csv')


def import_data(train_dataframe, dev_dataframe, test_dataframe):
    dataset = train_dataframe.values
    dataset = dataset.astype('float32')

    #Include all 12 initial factors (Year ; Month ; Hour ; Day ; Cloud Coverage ; Visibility ; Temperature ; Dew Point ;
    #Relative Humidity ; Wind Speed ; Station Pressure ; Altimeter
    max_test = np.max(dataset[:,9])
    min_test = np.min(dataset[:,9])
    scale_factor = max_test - min_test
    max = np.empty(13)
    min = np.empty(13)

    #Create training dataset
    for i in range(0,10):
        min[i] = np.amin(dataset[:,i],axis = 0)
        max[i] = np.amax(dataset[:,i],axis = 0)
        dataset[:,i] = normalize_data(dataset[:, i], min[i], max[i])

    train_data = dataset[:,0:9]
    train_labels = dataset[:,9]

    # Create dev dataset
    dataset = dev_dataframe.values
    dataset = dataset.astype('float32')

    for i in range(0, 10):
        dataset[:, i] = normalize_data(dataset[:, i], min[i], max[i])

    dev_data = dataset[:,0:9]
    dev_labels = dataset[:,9]

    # Create test dataset
    dataset = test_dataframe.values
    dataset = dataset.astype('float32')

    for i in range(0, 10):
        dataset[:, i] = normalize_data(dataset[:, i], min[i], max[i])

    test_data = dataset[:, 0:9]
    test_labels = dataset[:, 9]

    return train_data, train_labels, dev_data, dev_labels, test_data, test_labels, scale_factor


#drop unneccery columns

df.drop('Date',axis=1,inplace=True)
df.drop('(Inverters)',axis=1,inplace=True)

#normalize
df['Cloud coverage'] = (df['Cloud coverage']-(df['Cloud coverage'].mean()))/df['Cloud coverage'].std()
df['Visibility'] = (df['Visibility']-(df['Visibility'].mean()))/df['Visibility'].std()
df['Temperature'] = (df['Temperature']-(df['Temperature'].mean()))/df['Temperature'].std()
df['Dew point'] = (df['Dew point']-(df['Dew point'].mean()))/df['Dew point'].std()
df['Relative humidity'] = (df['Relative humidity']-(df['Relative humidity'].mean()))/df['Relative humidity'].std()
df['Station pressure'] = (df['Station pressure']-(df['Station pressure'].mean()))/df['Station pressure'].std()
df['Altimeter'] = (df['Altimeter']-(df['Altimeter'].mean()))/df['Altimeter'].std()
df['Solar energy'] = (df['Solar energy']-(df['Solar energy'].mean()))/df['Solar energy'].std()

weather_data = df.drop('Solar energy', axis= 1)
solar_data = df['Solar energy']


all_weather_data = weather_data[:].values
all_solar_data = solar_data[:].values

train_data_a = all_weather_data[:400]
train_targets_a = all_solar_data[:400]

val_data_a=all_weather_data[401:550]
val_targets_a=all_solar_data[401:550]

test_data = all_weather_data[551:]
test_targets = all_solar_data[551:]

 
train_dataframe = pd.read_csv('weather_train.csv', sep=";", engine='python', header = None)
dev_dataframe = pd.read_csv('weather_dev.csv', sep=";", engine='python', header = None)
test_dataframe = pd.read_csv( 'weather_test.csv', sep=";", engine='python', header = None)
train_data, train_labels, dev_data, dev_labels, test_data, test_labels, scale_factor = import_data(train_dataframe, dev_dataframe, test_dataframe)
time_steps = 1
X_train = np.reshape(train_data, (train_data.shape[0] // time_steps, time_steps, train_data.shape[1]))
X_dev = np.reshape(dev_data, (dev_data.shape[0] // time_steps, time_steps, dev_data.shape[1]))
X_test = np.reshape(test_data, (test_data.shape[0] // time_steps, time_steps, test_data.shape[1]))
Y_train = np.reshape(train_labels, (train_labels.shape[0] // time_steps, time_steps, 1))
Y_dev = np.reshape(dev_labels, (dev_labels.shape[0] // time_steps, time_steps, 1))
Y_test = np.reshape(test_labels, (test_labels.shape[0] // time_steps, time_steps, 1))


def build_model(): 
    model = Sequential()
    model.add(layers.Dense(64, activation='relu',input_shape=(train_data.shape[1],)))
    model.add(layers.Dense(64, activation='relu'))
    model.add(layers.Dense(1))
    model.compile(optimizer='rmsprop', loss='mse', metrics=['mae'])
    return model
def build_rnn_model(X_train):
    model = Sequential()
    model.add(layers.LSTM(32,
            dropout=0.2,
            recurrent_dropout=0.2,
            input_shape=(None, X_train.shape[1])))
    model.add(layers.Dense(1))
    model.compile(optimizer=RMSprop(), loss='mae')
    return model

#Set y values of data to lie between 0 and 1
def normalize_data(dataset, data_min, data_max):
    data_std = (dataset - data_min) / (data_max - data_min)
    test_scaled = data_std * (np.amax(data_std) - np.amin(data_std)) + np.amin(data_std)
    return test_scaled

def build_model_test(init_type = 'glorot_uniform', optimizer = 'adam', num_features = 9):
    model = Sequential()
    layers_list = [num_features, 64, 64, 1, 1]
    model.add(layers.LSTM(
        layers_list[0],
        input_shape = (None, num_features),
        return_sequences=True))
    model.add(layers.Dropout(0.2))

    model.add(layers.LSTM(
        layers_list[1],
        kernel_initializer = init_type,
        return_sequences=True
        #bias_initializer = 'zeros'
    ))
    model.add(layers.Dropout(0.2))

    model.add(layers.Dense(
        layers_list[2], activation='tanh',
        kernel_initializer=init_type,
        input_shape = (None, 1)
        ))
    model.add(layers.Dense(
        layers_list[3]))

    model.add(layers.Activation("relu"))
    model.compile(loss="mean_squared_error", optimizer=optimizer)

    return model
    
def mse(predicted, observed):
    return np.sum(np.multiply((predicted - observed),(predicted - observed)))/predicted.shape[0]

model = build_model() 
history=model.fit(train_data, train_labels,epochs=500, batch_size=40, validation_split=0.2)
test_mse_score, test_mae_score = model.evaluate(dev_data, dev_labels)
print('Average prediction you are off by is ', test_mae_score)
'''
model = build_model_test('glorot_uniform', 'adam')
model_fit_epochs = 100
print("X_train shape: ",X_train.shape, " Y_train shape: ",Y_train.shape)

model.fit(
    X_train, Y_train,
    batch_size = 16, epochs = model_fit_epochs)
trainset_predicted = model.predict(X_train)
devset_predicted = model.predict(X_dev)
testset_predicted = model.predict(X_test)

print("Train MSE: ", mse(trainset_predicted, Y_train) * scale_factor * scale_factor)
print("Dev MSE: ", mse(devset_predicted, Y_dev) * scale_factor * scale_factor)
print("Test MSE: ", mse(testset_predicted, Y_test) * scale_factor * scale_factor)

'''
